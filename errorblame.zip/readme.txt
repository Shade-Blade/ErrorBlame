Error Blame v1.0
A Google Translate mod for Bug Fables
By ShadeBlade

Install Instructions

If you don't have BepInEx already, download BepInEx (see link for latest release: https://github.com/BepInEx/BepInEx/releases)
To install BepInEx, copy the files directly below the BepInEx folder (should be another folder and some files) into the Bug Fables folder in Steam
	On Windows the Bug Fables folder is at C:\Program Files (x86)\Steam\steamapps\common\Bug Fables
Once you have installed BepInEx, copy the .dll file and the bundle file into the plugins folder in BepInEx
If you installed the mod correctly, the title screen will now read "Error Blame" instead of "Bug Fables".


If you find bugs, DM me on Discord (ShadeBlade#1198)
Don't report text going outside of boxes, since some of it is unfixable and the rest would take a very long time to fix